package tugas;

public interface Drawable {
    void draw();
}
