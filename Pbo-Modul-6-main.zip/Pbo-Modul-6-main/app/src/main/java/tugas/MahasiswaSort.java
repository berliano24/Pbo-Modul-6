package tugas;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import models.Mahasiswa;

public class MahasiswaSort {
    private List<Mahasiswa> dataMhs;

    public MahasiswaSort() {
        this.dataMhs = Loader.csvMhsLoad();
    }

    public List<Mahasiswa> sort(int sortBy) {
        if (sortBy == 1) {
            return dataMhs.stream()
                    .sorted(Comparator.comparing(Mahasiswa::getNama))
                    .toList();
        } else if (sortBy == 2) {
            return dataMhs.stream()
                    .sorted(Comparator.comparing(Mahasiswa::getIpk).reversed())
                    .toList();
        } else {
            return dataMhs.stream()
                    .sorted((m1, m2) -> m1.getNim().compareTo(m2.getNim()))
                    .toList();
        }
    }

    public double averageIpk() {
        return dataMhs.stream().mapToDouble(Mahasiswa::getIpk).average().orElse(0.0);
    }

    public List<Mahasiswa> filterCumlaude() {
        return dataMhs.stream().filter(mhs -> mhs.getIpk() >= 3.5).collect(Collectors.toList());
    }
}
